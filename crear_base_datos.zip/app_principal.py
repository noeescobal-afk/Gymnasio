import sqlite3

conn = sqlite3.connect('../database/gimnasio.db')
cursor = conn.cursor()

print("="*50)
print("     GIMNASIO FITLIFE - REPORTE ACTUAL")
print("="*50)

# Consulta: Mostrar cada clase con su instructor y cuántos socios están inscritos
cursor.execute('''
SELECT 
    c.nombre AS clase,
    i.nombre AS instructor,
    c.horario,
    COUNT(ins.id_socio) AS socios_inscritos,
    c.capacidad
FROM clases c
LEFT JOIN clases_instructores ci ON c.id_clase = ci.id_clase
LEFT JOIN instructores i ON ci.id_instructor = i.id_instructor
LEFT JOIN inscripciones ins ON c.id_clase = ins.id_clase
GROUP BY c.id_clase
''')

print(f"{'CLASE':<20} {'INSTRUCTOR':<18} {'HORARIO':<15} {'INSCRIPTOS':<12} {'CAPACIDAD'}")
print("-" * 80)

for clase, instructor, horario, inscritos, capacidad in cursor:
    print(f"{clase:<20} {instructor or 'Sin asignar':<18} {horario:<15} {inscritos:<12} {capacidad}")

conn.close()
print("\nConexión cerrada. ¡Todo funcionando!")