import sqlite3, os
ruta_db = os.path.join(os.path.dirname(os.path.dirname(__file__)), "database", "gimnasio.db")
conn = sqlite3.connect(ruta_db); c = conn.cursor()

print("SEMANA 13 – CRUD, CONSULTAS, ÍNDICES Y TRANSACCIONES\n" + "="*60)

# Índices
c.execute("CREATE INDEX IF NOT EXISTS idx_socio_dni ON socios(dni)")
c.execute("CREATE INDEX IF NOT EXISTS idx_clase_nombre ON clases(nombre)")

# CRUD
c.execute("INSERT INTO socios (dni,nombre,email) VALUES ('99999999','Luis Nuevo','luis@gym.com')")
c.execute("UPDATE clases SET capacidad=35 WHERE nombre='Spinning Power'")
c.execute("DELETE FROM inscripciones WHERE id_socio=3")

# Consultas avanzadas
c.execute("""SELECT c.nombre, i.nombre, COUNT(ins.id_socio) inscritos, c.capacidad
             FROM clases c
             LEFT JOIN clases_instructores ci ON c.id_clase=ci.id_clase
             LEFT JOIN instructores i ON ci.id_instructor=i.id_instructor
             LEFT JOIN inscripciones ins ON c.id_clase=ins.id_clase
             GROUP BY c.id_clase""")
print("JOIN + COUNT:")
for row in c.fetchall(): print(row)

c.execute("SELECT nombre FROM socios WHERE id_socio IN (SELECT id_socio FROM inscripciones GROUP BY id_socio HAVING COUNT()>1)")
print("\nSubconsulta (socios en más de 1 clase):")
for row in c.fetchall(): print(row)

print("\n--- TRANSACCIÓN SEGURA (con with conn) ---")
try:
    with conn:   # ← esto reemplaza BEGIN + COMMIT y hace rollback si hay error
        c.execute("INSERT INTO inscripciones (id_socio, id_clase) VALUES (1, 2)")
        c.execute("UPDATE clases SET capacidad = capacidad - 1 WHERE id_clase = 2")
        print("→ Inscripción añadida y capacidad reducida correctamente")
except sqlite3.Error as e:
    print("¡Error! Transacción cancelada automáticamente:", e)