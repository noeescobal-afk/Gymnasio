import sqlite3
import os

# Ruta absoluta para que funcione SIEMPRE
ruta_actual = os.path.dirname(os.path.abspath(__file__))      # carpeta src
ruta_proyecto = os.path.dirname(ruta_actual)                  # sube a la raíz
ruta_db = os.path.join(ruta_proyecto, "database", "gimnasio.db")

# Crea la carpeta database si no existe
os.makedirs(os.path.dirname(ruta_db), exist_ok=True)

print("Creando base de datos en:")
print(ruta_db)
print()

# Conectar (o crear) la base de datos
conn = sqlite3.connect(ruta_db)
cursor = conn.cursor()

# Crear tablas
cursor.execute('DROP TABLE IF EXISTS clases_instructores')
cursor.execute('DROP TABLE IF EXISTS inscripciones')
cursor.execute('DROP TABLE IF EXISTS clases')
cursor.execute('DROP TABLE IF EXISTS instructores')
cursor.execute('DROP TABLE IF EXISTS socios')

cursor.execute('''
CREATE TABLE socios (
    id_socio INTEGER PRIMARY KEY AUTOINCREMENT,
    dni TEXT UNIQUE NOT NULL,
    nombre TEXT NOT NULL,
    telefono TEXT,
    email TEXT UNIQUE
)
''')

cursor.execute('''
CREATE TABLE instructores (
    id_instructor INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    especialidad TEXT
)
''')

cursor.execute('''
CREATE TABLE clases (
    id_clase INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT UNIQUE NOT NULL,
    horario TEXT,
    capacidad INTEGER CHECK(capacidad > 0)
)
''')

cursor.execute('''
CREATE TABLE inscripciones (
    id_inscripcion INTEGER PRIMARY KEY AUTOINCREMENT,
    id_socio INTEGER,
    id_clase INTEGER,
    FOREIGN KEY(id_socio) REFERENCES socios(id_socio) ON DELETE CASCADE,
    FOREIGN KEY(id_clase) REFERENCES clases(id_clase) ON DELETE CASCADE,
    UNIQUE(id_socio, id_clase)
)
''')

cursor.execute('''
CREATE TABLE clases_instructores (
    id_clase INTEGER,
    id_instructor INTEGER,
    PRIMARY KEY(id_clase, id_instructor),
    FOREIGN KEY(id_clase) REFERENCES clases(id_clase) ON DELETE CASCADE,
    FOREIGN KEY(id_instructor) REFERENCES instructores(id_instructor) ON DELETE CASCADE
)
''')

# Insertar datos de prueba
cursor.executemany("INSERT INTO socios (dni, nombre, telefono, email) VALUES (?, ?, ?, ?)", [
    ("11111111", "Juan Pérez", "987654321", "juan@gmail.com"),
    ("22222222", "María López", "912345678", "maria@gmail.com"),
    ("33333333", "Carlos Ruiz", "998877665", None)
])

cursor.executemany("INSERT INTO instructores (nombre, especialidad) VALUES (?, ?)", [
    ("Pedro Gómez", "CrossFit"),
    ("Laura Díaz", "Yoga"),
    ("Miguel Ángel", "Spinning")
])

cursor.executemany("INSERT INTO clases (nombre, horario, capacidad) VALUES (?, ?, ?)", [
    ("CrossFit Morning", "Lun-Mie-Vie 07:00", 20),
    ("Yoga Relax", "Mar-Jue 18:30", 25),
    ("Spinning Power", "Lun a Vie 19:00", 30)
])

cursor.execute("INSERT INTO inscripciones (id_socio, id_clase) VALUES (1,1),(1,3),(2,2),(3,1),(2,1)")
cursor.execute("INSERT INTO clases_instructores VALUES (1,1),(2,2),(3,3)")

conn.commit()
conn.close()

print("BASE DE DATOS CREADA CORRECTAMENTE")
print("Archivo creado en:")
print(ruta_db)
print("Puedes verlo en la carpeta 'database'")