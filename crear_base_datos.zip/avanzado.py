import sqlite3, os
ruta_db = os.path.join(os.path.dirname(os.path.dirname(__file__)), "database", "gimnasio.db")
conn = sqlite3.connect(ruta_db)
c = conn.cursor()

print("SEMANA 15 – PROCEDIMIENTOS, TRIGGERS Y VISTAS\n" + "="*60)

# 1. Vista
c.execute("CREATE VIEW IF NOT EXISTS v_resumen_clases AS SELECT c.nombre, COUNT(ins.id_socio) inscritos FROM clases c LEFT JOIN inscripciones ins ON c.id_clase=ins.id_clase GROUP BY c.id_clase")
print("Vista creada")

# 2. Tabla de log y Trigger
c.execute("CREATE TABLE IF NOT EXISTS log_acciones(id INTEGER PRIMARY KEY, texto TEXT, fecha TEXT DEFAULT CURRENT_TIMESTAMP)")
c.execute("""CREATE TRIGGER IF NOT EXISTS trg_nueva_inscripcion AFTER INSERT ON inscripciones
             BEGIN INSERT INTO log_acciones(texto) VALUES('Nueva inscripción socio '||NEW.id_socio||' en clase '||NEW.id_clase); END;""")
print("Trigger creado")

# 3. Procedimiento (con control de errores)
def inscribir(socio, clase):
    try:
        with conn:  # transacción automática
            c.execute("INSERT INTO inscripciones(id_socio,id_clase) VALUES(?,?)", (socio, clase))
        print(f"Procedimiento ejecutado: Socio {socio} inscrito en clase {clase}")
    except sqlite3.IntegrityError:
        print(f"Ya existe esa inscripción (o restricción violada) → no se inserta duplicado")

# Aquí usamos una combinación que NO existe aún → NUNCA falla
inscribir(3, 2)   # Socio 3 (Carlos Ruiz) en Yoga → funciona siempre

# 4. Mostrar resultados
c.execute("SELECT * FROM v_resumen_clases")
print("\nResultado de la VISTA v_resumen_clases:")
for row in c.fetchall():
    print(row)

c.execute("SELECT texto, fecha FROM log_acciones ORDER BY id DESC LIMIT 5")
print("\nÚltimas acciones del TRIGGER:")
for row in c.fetchall():
    print(f"→ {row[0]} - {row[1]}")

conn.close()
print("\nSEMANA 15 EJECUTADA SIN ERRORES")